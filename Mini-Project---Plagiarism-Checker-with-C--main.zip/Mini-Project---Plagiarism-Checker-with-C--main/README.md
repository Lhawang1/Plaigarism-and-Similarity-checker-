# Plagiarism Checker (C++ + PHP)

A simple web-based tool to compare two text files and show their plagiarism percentage.

## Files

* **index.html** – Upload form (UI)
* **style.css** – Page styling
* **upload.php** – Handles uploads and runs the C++ program
* **plagcheck.cpp** – C++ code that compares files
* **uploads/** – Stores uploaded files

## How It Works

1. User uploads two files from `index.html`.
2. `upload.php` saves them to `uploads/` and runs:

   ```
   shell_exec("plagcheck.exe file1 file2");
   ```
3. The C++ program reads both files, compares word overlap, and prints a plagiarism percentage.

## Setup (Windows + XAMPP)

1. Install **XAMPP** (Apache + PHP).
2. Copy the project to:
   `C:\xampp\htdocs\PlagiarismChecker`
3. Compile C++ program:

   ```
   g++ plagcheck.cpp -o plagcheck.exe
   ```

   (Keep `plagcheck.exe` in the same folder as `upload.php`.)
4. Start Apache and open:
   [http://localhost/PlagiarismChecker/index.html](http://localhost/PlagiarismChecker/index.html)
5. Upload two `.txt` files → get plagiarism result.

## Tips

* If no result appears, check Apache/PHP error logs.
* Make sure `shell_exec` isn’t disabled in `php.ini`.
* Keep file uploads small and in text format only.

## Example (Command Line)

```
g++ plagcheck.cpp -o plagcheck.exe
plagcheck.exe file1.txt file2.txt
```

Output: `Plagiarism Percentage: 66.67%`

**Note:** This is an educational demo. For real use, add file validation and security measures.
