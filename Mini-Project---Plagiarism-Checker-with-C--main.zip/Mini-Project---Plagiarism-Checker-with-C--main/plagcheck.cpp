#include <bits/stdc++.h>
using namespace std;

// Function to read whole file content
string readFile(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Error: Could not open file " << filename << endl;
        exit(1);
    }
    stringstream buffer;
    buffer << file.rdbuf();
    return buffer.str();
}

// Function to clean text: lowercase + remove punctuation
string cleanText(string text) {
    for (char &c : text) {
        if (ispunct(c)) c = ' '; // replace punctuation with space
        c = tolower(c);          // convert to lowercase
    }
    return text;
}

// Split text into words
vector<string> splitWords(const string& text) {
    vector<string> words;
    string word;
    stringstream ss(text);
    while (ss >> word) {
        words.push_back(word);
    }
    return words;
}

// Calculate similarity percentage
double calculateSimilarity(vector<string> &w1, vector<string> &w2) {
    if (w1.empty() || w2.empty()) return 0.0;

    unordered_set<string> set1(w1.begin(), w1.end());
    int common = 0;

    for (string &word : w2) {
        if (set1.find(word) != set1.end()) {
            common++;
        }
    }

    double total = (w1.size() + w2.size()) / 2.0;
    return (common / total) * 100.0;
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        cout << "Usage: plagcheck file1 file2" << endl;
        return 1;
    }

    string text1 = cleanText(readFile(argv[1]));
    string text2 = cleanText(readFile(argv[2]));

    vector<string> words1 = splitWords(text1);
    vector<string> words2 = splitWords(text2);

    double similarity = calculateSimilarity(words1, words2);

    cout << "Plagiarism Percentage: " 
         << fixed << setprecision(2) << similarity << "%" << endl;

    return 0;
}
