<?php
// Create uploads folder if it doesn't exist
$uploadDir = "uploads/";
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0777, true); // permissions 0777
}

if ($_FILES["file1"]["error"] == 0 && $_FILES["file2"]["error"] == 0) {

    // Save uploaded files in uploads/ folder
    $file1Path = $uploadDir . basename($_FILES["file1"]["name"]);
    $file2Path = $uploadDir . basename($_FILES["file2"]["name"]);

    move_uploaded_file($_FILES["file1"]["tmp_name"], $file1Path);
    move_uploaded_file($_FILES["file2"]["tmp_name"], $file2Path);

    // Run your C++ program
    // Windows: "plagcheck.exe"
    // Linux/Mac: "./plagcheck.out"
    $output = shell_exec("plagcheck.exe $file1Path $file2Path");

    // Display result
    echo "<div style='padding:20px; font-family:Arial;'>";
    echo "<h2>Plagiarism Checker Result</h2>";
    echo "<pre style='background:#f4f4f4; padding:15px; border-radius:6px;'>$output</pre>";
    echo "<a href='index.html'>⬅ Back</a>";
    echo "</div>";

} else {
    echo "Error uploading files!";
}
?>
